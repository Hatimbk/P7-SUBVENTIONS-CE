package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class Subvention implements Serializable{

	@Id
	@GeneratedValue
	
	private long id;
	private String code;
	private String libelle;
	private String montant;
	public Subvention() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Subvention(long id, String code, String libelle, String montant) {
		super();
		this.id = id;
		this.code = code;
		this.libelle = libelle;
		this.montant = montant;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getMontant() {
		return montant;
	}
	public void setMontant(String montant) {
		this.montant = montant;
	}
	
}
