package com.example.demo.entities;

import java.io.Serializable;
import javax.persistence.*;
@Entity

public class Panier implements Serializable{
	@Id
	@GeneratedValue	
	private long id;

	public Panier() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Panier(long id) {
		super();
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
}

