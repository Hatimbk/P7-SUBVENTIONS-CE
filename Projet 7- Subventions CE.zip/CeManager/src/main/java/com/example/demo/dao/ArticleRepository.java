package com.example.demo.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Article;

public interface ArticleRepository extends JpaRepository<Article, Long>{
	public List<Article> findByCode(String n);
	@Query("select e from Article e where e.id = :id")
	public List<Article> findById(@Param("id") long id);
	
	public Page<Article> findByCode(String n,Pageable pageable);
//	@Query("select e from article e where e.code like :x")
//	public Page<Article> chercherArticle(@Param("x")String mc,Pageable pageable);
//	
	
}
