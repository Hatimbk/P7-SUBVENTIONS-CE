package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.*;
@Entity

public class Article implements Serializable{
	@Id
	@GeneratedValue
	private long id;
	private String code;
	private String libelle;
	private String prix;
	public Article() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Article(long id, String code, String libelle, String prix) {
		super();
		this.id = id;
		this.code = code;
		this.libelle = libelle;
		this.prix = prix;
	}

	@Override
	public String toString() {
		return "Article [id=" + id + ", code=" + code + ", libelle=" + libelle + ", prix=" + prix + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getPrix() {
		return prix;
	}
	public void setPrix(String prix) {
		this.prix = prix;
	}
	
}
