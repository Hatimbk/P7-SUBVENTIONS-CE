package com.example.demo.entities;

public class Commande {

}
