package com.example.demo;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.example.demo.dao.ArticleRepository;
import com.example.demo.entities.Article;

import ch.qos.logback.core.net.SyslogOutputStream;

@SpringBootApplication
public class CeManagerApplication {

	public static void main(String[] args) {
	 org.springframework.context.ApplicationContext ctx =  SpringApplication.run(CeManagerApplication.class, args);
	 ArticleRepository articleRepository = ctx.getBean(ArticleRepository.class);
//	 articleRepository.save(new Article(1,"Telephone","Samsung S6","300"));
//	 articleRepository.save(new Article(2,"TeleVision","LG Se","400"));
//	 articleRepository.save(new Article(3,"PC portable","Azus","500"));
	 articleRepository.save(new Article(7,"PC fixe","Azus","500"));
	 Page<Article> artds = articleRepository.findAll(new PageRequest(0, 3));
	 artds.forEach(e->System.out.println(e.getCode()));
	 
	}
}
