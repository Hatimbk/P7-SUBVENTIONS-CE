package com.example.demo.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dao.ArticleRepository;
import com.example.demo.entities.Article;

@Controller

public class ArticleController {
	@Autowired
	private ArticleRepository articleRepository;
	@Secured(value={"ROLE_ADMIN"})
	@RequestMapping(value="/Index")
	public String Index(Model model){
		List<Article> artcles = articleRepository.findAll();
		model.addAttribute("articles",artcles);
		model.addAttribute("article",new Article());
		return "articles";
	}
	
	@RequestMapping(value="/articles")
	public String listeArticles(Model model){
		List<Article> artcles = articleRepository.findAll();
		model.addAttribute("articles",artcles);
		//model.addAttribute("article",new Article());
		return "listeArticles";
	}
	@RequestMapping(value="/SaveArticle",method=RequestMethod.POST)
	public String save(Article article ){
		articleRepository.save(article);
		
		//.addAttribute("article",new Article());
		
		return "redirect:articles";
		
	} 
	@RequestMapping(value="/prestations")
	public String prestation(  ){
		return "prestations";
	}
	
	@RequestMapping(value="/subventions")
	public String subventions(  ){
		return "subventions";
	}
	
	@RequestMapping(value = "/articles/{id}/delete", method = RequestMethod.GET)
	public String deleteArticle(@PathVariable("id") long id ){
		List<Article> articles = articleRepository.findById(id);
		if(articles.size()>0){
		articleRepository.delete(articles.get(0));
		}
		//.addAttribute("article",new Article());
		//return new ResponseEntity<Article>(HttpStatus.NO_CONTENT);
		return "redirect:/articles";
		
	}
}