package com.example.demo.web;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dao.UtilisateurRepository;
import com.example.demo.entities.Utilisateurs;
@Controller

public class UtilisateurController {
	@Autowired
	private UtilisateurRepository utilisateurRepository;
	@RequestMapping(value="/login")
	public String user(Model mod){
		return "authent";
		
	}
	@RequestMapping(value="/saveUser", method=RequestMethod.POST)
	public String saveUser(Utilisateurs utilisateurs){
		utilisateurRepository.save(utilisateurs);
		return "saveUser";
	}
	@RequestMapping(value="/employe")
	public String employe(Utilisateurs utilisateurs) {
		return "employe";
	}
}
