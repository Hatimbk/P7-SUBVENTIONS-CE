package com.example.demo.entities;

import java.io.Serializable;
import javax.persistence.*;
@Entity
public class Prestation implements Serializable{
	@Id
	@GeneratedValue
	private long id;
	private String code;
	private String etat;
	public Prestation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Prestation(long id, String code, String etat) {
		super();
		this.id = id;
		this.code = code;
		this.etat = etat;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getEtat() {
		return etat;
	}
	public void setEtat(String etat) {
		this.etat = etat;
	}
	
}
